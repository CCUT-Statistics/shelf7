	include _include(APP_PATH.'plugin/sg_invite_vip/model/sg_invite_vip.func.php');
