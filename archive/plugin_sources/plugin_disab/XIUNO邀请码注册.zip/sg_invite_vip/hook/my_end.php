<?php exit;
elseif ($action == 'sg_invite') {
    $kv_invite = setting_get('sg_invite');
	switch ($kv_invite['resources']) {
		case 'credits':
			$resources = lang('sg_credits');
			break;

		case 'golds':
			$resources = lang('sg_golds');
			break;

		case 'rmbs':
			$resources = lang('sg_rmbs');
			break;
	}
	
	if ($method == 'GET') {
		
		$pagesize = 10;
		$page = param(2, 1);
		$f = param(3, 0);
		
		if ($f == '1') {
			$cond = array('buy_uid'=>$uid, 'use_date'=>array('>'=>'0'));
			$invitetitle = lang('sg_already_used');
		} else {
			$cond = array('buy_uid'=>$uid, 'use_date'=>'0');
			$invitetitle = lang('sg_not_used');
		}
		
		$invitecount = sg_invite_count($cond);
		$pagination = pagination(url("my-sg_invite-{page}-{$f}") , $invitecount, $page, $pagesize);
		$invitelist = sg_invite_find($cond, array() , $page, $pagesize);
		
		include _include(APP_PATH . 'plugin/sg_invite_vip/htm/sg_invite.htm');
		
	} else {
		
		$kv_invite['purchase'] != 1 and message(0, lang('sg_invite_create_close'));
		
		if (array_key_exists($gid, $kv_invite['group'])) {
			
			$number = param('number', 1);
			empty($number) AND message('number', lang('sg_purchase_quantity'));
			$userinvitecount = sg_invite_count(array('buy_uid'=>$uid, 'use_date'=>'0'));
			($userinvitecount + $number) > $kv_invite['number'] AND message(0, lang('sg_user_invite_not_count'));
			$creditsnum = $number * $kv_invite['price'];
			$user[$kv_invite['resources']] < $creditsnum AND message('number', lang('sg_user_not_resources', array('resources'=>$resources)));
			
			if ($number > 0) {
				
				user_update($uid, array($kv_invite['resources'].'-'=>$creditsnum));
				sg_invite_create($number, $uid, $user['username'], $kv_invite['expiry']);
				$message = lang('sg_invite_create_sucessfully', array('number'=>$number));
				
			}
			
		} else {
			
			$message = lang('sg_user_not_group');
			
		}
		
		message(0, $message);
		
	}
	
}
?>
