<?php exit;
		sg_invite_update($invitcode,array('use_date'=>time(), 'use_username'=>$username));
?>