<?php exit;
		$invitcode = param('invitcode');
		empty($invitcode) AND message('invitcode', lang('sg_please_input_invite'));
		$invdata = sg_invite_read($invitcode);
		if(!empty($invdata)){
			isset($invdata['use_username']) && isset($invdata['use_date']) AND message('invitcode', lang('sg_already_used_invite'));
			($invdata['expiry_date'] - $time) < 0 AND message('invitcode', lang('sg_expiry_invite'));
		}else{
			message('invitcode', lang('sg_invite_not_exists'));
		}
?>