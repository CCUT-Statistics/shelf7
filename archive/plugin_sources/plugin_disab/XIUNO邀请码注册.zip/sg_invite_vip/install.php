<?php

/*
	Xiuno BBS 4.0 邀请码设置
	xiuno爱好者网 https://xiu.no
*/

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;
$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}sg_invite (
  `invitid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '邀请码ID',
  `invitcode` char(12) COLLATE utf8_general_ci NOT NULL COMMENT '邀请码',
  `create_date` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '生成时间',
  `use_date` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '使用时间',
  `expiry_date` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '过期时间',
  `use_username` varchar(32) COLLATE utf8_general_ci DEFAULT NULL COMMENT '使用人',
  `buy_username` varchar(32) COLLATE utf8_general_ci DEFAULT NULL COMMENT '购买人',
  `buy_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '购买人ID',
  PRIMARY KEY (`invitid`),
  UNIQUE KEY (`invitcode`),
  KEY (`buy_uid`, `use_date`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci";

$r = db_exec($sql);
$r === FALSE AND message(-1, '创建邀请码表结构失败');
$kv = array('purchase'=>'1', 'group'=> array('1'=>1,'2'=>1,'4'=>1,'5'=>1,'101'=>1,'102'=>1,'103'=>1,'104'=>1,'105'=>1), 'resources'=>'golds', 'price'=>'10', 'number'=>'10', 'expiry'=>'30');
setting_set('sg_invite', $kv);
is_dir(APP_PATH.'plugin/sg_invite/') AND plugin_unstall('sg_invite');
?>