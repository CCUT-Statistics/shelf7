<?php
/*
	Xiuno BBS 4.0 邀请码 函数文件
*/

function sg_invite__create($arr) {
	$r = db_create('sg_invite', $arr);
	return $r;
}

function sg_invite_delete($cond = array()) {
	$r = db_delete('sg_invite', $cond);
	return $r;
}

function sg_invite_update($invitcode, $arr) {
	$r = db_update('sg_invite', array('invitcode'=>$invitcode), $arr);
	return $r;
}

function sg_invite_read($invitcode) {
	$r = db_find_one('sg_invite', array('invitcode'=>$invitcode));
	return $r;
}

function sg_invite_count($cond = array()) {
	$n = db_count('sg_invite', $cond);
	return $n;
}

function sg_invite_find($cond = array(), $orderby = array(), $page = 1, $pagesize = 20) {
	$invitelist = db_find('sg_invite', $cond, $orderby, $page, $pagesize);
	return $invitelist;
}

function sg_invite_find_by_ids($ids) {
	if (!$ids) return array();
	$sg_invitelist = db_find('sg_invite', array('invitid' => $ids) , array('invitid'=>1), 1, 1000, 'invitid');
	return $sg_invitelist;
}

function sg_invite_create($number ,$buy_uid ,$buy_username ,$expiry) {
	global $time;
	$expiry_date = $time + ($expiry * 86400);
		for($i = 0;$i < $number;$i++) {
			$invitcode = strtoupper(md5(uniqid(rand() , true)));
			$arr = array('invitcode'=>substr($invitcode, 0, 12), 'use_date'=>'0', 'buy_uid'=>$buy_uid, 'buy_username'=>$buy_username, 'create_date'=>$time, 'expiry_date'=>$expiry_date);
			$r = sg_invite__create($arr);
		}
	
	return $r;
}
?>
