<?php
/*
	Xiuno BBS 4.0 邀请码设置
	xiuno爱好者网 https://xiu.no
*/
!defined('DEBUG') AND exit('Access Denied.');
$kv = setting_get('sg_invite');
function sg_form_multi_checkbox($name, $arr, $checked = array()) {
	$s = '';
	foreach($arr as $k=>$v) {
		$ischecked = array_key_exists($k, $checked);
		$s .= form_checkbox($name."[$k]", $ischecked, $v).' ';
	}
	return $s;
}
$action = param(3);

if(empty($action)) {
	
	if($method == 'GET') {
		
	unset($grouplist[0]);
	unset($grouplist[6]);
	unset($grouplist[7]);
	$input = array();
	$input['purchase'] = form_radio_yes_no('purchase', $kv['purchase']);
	$group = arrlist_key_values($grouplist, 'gid', 'name');
	$input['group']= sg_form_multi_checkbox("group", $group, $kv['group']);
	$input['resources'] = form_select('resources',array('credits'=> lang('sg_credits'), 'golds'=> lang('sg_golds'), 'rmbs'=> lang('sg_rmbs')), $kv['resources']);
	$input['price'] = form_text('price', $kv['price']);
	$input['number'] = form_text('number', $kv['number']);
	$input['expiry'] = form_text('expiry', $kv['expiry']);
	empty($kv['url']) AND $kv['url'] = '';
	$input['url'] = form_text('url', $kv['url']);
	include _include(APP_PATH.'plugin/sg_invite_vip/htm/setting.htm');
	
	} else {
		
	$kv = array();
	$kv['purchase'] = param('purchase', 0);
	$kv['group'] =param('group', array(0));
	$kv['resources'] = param('resources', '', FALSE);
	$kv['price'] = param('price', 0);
	$kv['number'] = param('number', 0);
	$kv['expiry'] = param('expiry', 0);
	$kv['url'] = param('url');
	setting_set('sg_invite', $kv);
	$message = lang('save_successfully');
	message(0, $message);	
	
	}
	
} elseif($action == 'list') {

	$page = param(4, 1);
	$pagesize = _COOKIE('sg_invite_pagesize') ? _COOKIE('sg_invite_pagesize') : 10;
	$type = _COOKIE('sg_invite_type') ? _COOKIE('sg_invite_type') : 0;
	if($type == '1') {
		
		$cond =  array('use_date'=>'0');
		$invitetitle = lang('sg_not_used');
		
	}elseif($type == '2') {
		
		$cond =  array('use_date'=>array('>'=>'0'));
		$invitetitle = lang('sg_already_used');
		
	}else{
		
		$cond = array();
		$invitetitle = lang('all');
	}	
	
	$invitecount = sg_invite_count($cond);
	$pagination = pagination(url("plugin-setting-sg_invite_vip-list-{page}"), $invitecount, $page, $pagesize);
	$invitelist = sg_invite_find($cond, array(), $page, $pagesize);
	include _include(APP_PATH.'plugin/sg_invite_vip/htm/setting_list.htm');
	
} elseif($action == 'create') {
	
	if($method == 'GET') {
		
		include _include(APP_PATH.'plugin/sg_invite_vip/htm/setting_create.htm');
	
	} else {
		
		$number = param('number');
		empty($number) AND message('number', lang('sg_purchase_quantity'));
		
		if($number  > 0) {
			sg_invite_create($number ,$uid ,$user['username'] ,$kv['expiry']);
			$message = lang('sg_invite_create_sucessfully', array('number'=>$number));
			message(0, $message);
		}
		
	}
	
} elseif($action == 'delete') {
	
	if($method == 'GET') {
		
		include _include(APP_PATH.'plugin/sg_invite_vip/htm/setting_delete.htm');
	
	} else {
		$invitidarr = param('invitidarr', array(0));
		empty($invitidarr) AND message(-1, lang('sg_please_check_delete_invite'));
		
		foreach($invitidarr as $invitid) {
			$r = sg_invite_delete(array('invitid'=>$invitid));
		}
		
		$r === FALSE AND message(-1, lang('delete_failed'));
		$message = lang('forum_delete_successfully');
		message(0, $message);
	} 
		
} elseif($action == 'export') {
	
	if($method == 'GET') {
		
		include _include(APP_PATH.'plugin/sg_invite_vip/htm/setting_export.htm');
	
	} else {		
		$invitidarr = param('invitidarr', array(0));
		empty($invitidarr) AND message(-1, lang('sg_please_check_export_invite'));
		
		$sg_invitelist = sg_invite_find_by_ids($invitidarr);
		
		$tmpanme = 'invitelist.txt';
		$tmpfile = $conf['upload_path'].'tmp/'.$tmpanme;
		$tmpurl = url("plugin-setting-sg_invite_vip-download-$time");

		$invitelist = '';
		foreach ($sg_invitelist as $sg_invite) {
			$invitelist .= "$sg_invite[buy_username]  $sg_invite[invitcode] \r\n";
		}
		
		file_put_contents($tmpfile, $invitelist) OR message(-1, lang('write_to_file_failed'));
		message(0, $tmpurl);
	}
} elseif($action == 'download') {

	$attachpath = $conf['upload_path'].'tmp/invitelist.txt';
	!is_file($attachpath)AND message(-1, lang('attach_not_exists'));
	$orgfilename = lang('sg_invite').'_'.date("Y-m-d H:i:s", $time).'.txt';

	if(stripos($_SERVER["HTTP_USER_AGENT"], 'MSIE') !== FALSE || stripos($_SERVER["HTTP_USER_AGENT"], 'Edge') !== FALSE || stripos($_SERVER["HTTP_USER_AGENT"], 'Trident') !== FALSE) {
		$orgfilename = urlencode($orgfilename);
		$orgfilename = str_replace("+", "%20", $orgfilename);
	}
	
	$timefmt = date('D, d M Y H:i:s', $time).' GMT';
	header('Date: '.$timefmt);
	header('Last-Modified: '.$timefmt);
	header('Expires: '.$timefmt);
	header('Cache-control: max-age=86400');
	header('Content-Transfer-Encoding: binary');
	header("Pragma: public");
	header('Content-Disposition: attachment; filename="'.$orgfilename.'"');
	header('Content-Type: application/octet-stream');

	readfile($attachpath);

	exit;
} 
?>