<?php

/*
	Xiuno BBS 4.0 邀请码设置
	xiuno爱好者网 https://xiu.no
*/

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;
$sql = "DROP TABLE IF EXISTS {$tablepre}sg_invite;";

$r = db_exec($sql);
$r = kv_delete('sg_invite');
$r === FALSE AND message(-1, '卸载邀请码表失败');

?>