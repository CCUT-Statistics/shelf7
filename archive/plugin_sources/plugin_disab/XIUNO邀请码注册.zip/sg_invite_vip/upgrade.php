<?php

/*
	Xiuno BBS 4.0 邀请码设置
	xiuno爱好者网 https://xiu.no
*/

!defined('DEBUG') AND exit('Forbidden');
$kv = kv_get('sg_invite');
if($kv) {
	$kv = array('purchase'=>$kv['purchase'], 'group'=> $kv['group'], 'resources'=>$kv['resources'], 'price'=>$kv['price'], 'number'=>$kv['number'], 'expiry'=>$kv['expiry']);
	setting_set('sg_invite', $kv);
	kv_delete('sg_invite');
}

?>