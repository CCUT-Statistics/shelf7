<?php

!defined('DEBUG') and exit('Forbidden');

/* 【开始】金桔框架——常量定义 */

$BASE_URL = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$BASE_URL = empty($BASE_URL) ? '/' : '/' . trim($BASE_URL, '/') . '/';

define('WEBSITE_DIR', $_SERVER["HTTP_HOST"] . $BASE_URL);
define('PLUGIN_DIR', 'plugin/' . param(2) . '/');
define('PLUGIN_NAME', param(2));
include_once(APP_PATH . PLUGIN_DIR . 'conf.php');
$PLUGIN_SETTING = setting_get(PLUGIN_NAME . '_setting');

/* 【结束】金桔框架——常量定义 */

/**
 * 金桔框架——初始化设置
 * @param array $data 要导入的设置数组。
 * @return array 每一个设置项
 */
function kumquat_setting_init($data) {
    $setting = array();
    if (!isset($data['panels'])) {
        return $setting;
    } else {
        foreach ($data['panels'] as $panel => $value) {
            $controller_name_panel = $panel;
            foreach ($value['sections'] as $section => $value) {
                $controller_name_section = $controller_name_panel . '/' . $section;
                foreach ($value['options'] as $option => $control) {
                    $controller_name = $controller_name_section . '/' . $option;
                    if (isset($control['default'])) {
                        $setting[$controller_name] = $control['default'];
                    } else {
                        $setting[$controller_name] = 0;
                    }
                }
            }
        }
    }
    return $setting;
}

if (empty($PLUGIN_SETTING)) {
    $setting = kumquat_setting_init($data);
    setting_set(PLUGIN_NAME . '_setting', $setting);
}

$tablepre = $db->tablepre;
$sql = "ALTER TABLE {$tablepre}forum ADD COLUMN color varchar(64) NOT NULL default ''";

$r = db_exec($sql);