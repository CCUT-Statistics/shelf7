<?php exit;
$pnumber = $thread['vip_only'];
$input['vip_only'] = form_radio_yes_no('vip_only', $pnumber > 0 ? 1 : 0);
?>