<?php exit;
$vip_only = param('vip_only'); 
if ($vip_only>0)
    db_update('thread', array('tid' => $tid), array('vip_only' => 1));
else
    db_update('thread', array('tid' => $tid), array('vip_only' => 0));
?>