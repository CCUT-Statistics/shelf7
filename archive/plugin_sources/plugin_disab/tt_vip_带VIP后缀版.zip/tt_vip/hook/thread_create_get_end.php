<?php exit;
$pnumber=0;
$input['vip_only'] = form_radio_yes_no('vip_only', 0);
?>