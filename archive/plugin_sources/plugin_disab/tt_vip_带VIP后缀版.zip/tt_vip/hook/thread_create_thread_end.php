$vip_only = param('vip_only'); 
if ($vip_only>-1)
    {db_update('thread', array('tid' => $tid), array('vip_only' => $vip_only));}