<?php exit;
    $gid=isset($user['gid'])?$user['gid']:'0';  
  
	if($gid != 1){

      if($user['vip_end'] < time() && $thread['vip_only'] > 0){
          message(-1, jump("该贴为优质内容，仅超级会员可查看，前往开通...", "my-vip.htm", 2));
        die();
      }
      
    }

$spay_url = url('my-vip');
$html_pay='<div class="alert alert-warning" role="alert"> <i class="icon-shopping-cart" style="color:gold;" aria-hidden="true" title="ttPay"></i> '.$conf['sitename'].' - 超级会员可见<hr/>本帖含有超级会员专属优质内容， 请开通后再查看 </span><button id="b_p" type="submit" style="text-decoration: none; color:white;float:right;" class="btn btn-warning mr-2   data-loading-text="'.lang('submiting').'..." data-modal-url="my-tt_vip_open.htm" data-modal-title="开通超级会员" data-modal-size="lg" >立即开通</button><div style="clear:both;"></div></div>';
$preg_pay = preg_match_all('/\[ttvip\](.*?)\[\/ttvip\]/i',$first['message_fmt'],$array);
 
 
	if($preg_pay){
		$array_count = count($array[0]);
		for($i=0;$i<$array_count;$i++){
			$a = $array[0][$i];
			$b = '<div class="alert alert-success" role="alert"> <i class="icon-shopping-cart" style="color:green;" aria-hidden="true" title="ttvip"></i> '.$conf['sitename'].' -  超级会员可见'.'<div style="float:right;"><a href="'.$spay_url.'">我的会员</a></div><hr/>'.$array[1][$i].'</div>';
			if($user['vip_end'] > time()||$thread['uid']==$uid) $first['message_fmt'] = str_replace($a,$b,$first['message_fmt']);
 
			else $first['message_fmt'] = str_replace($a,$is_set==0?$html_pay:'',$first['message_fmt']); $is_set=1;$first['purchased']='0';
		}
	}
 
	
	 
?>