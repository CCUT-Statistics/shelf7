<?php
// 跳过路由
define('SKIP_ROUTE', TRUE);
define('APP_PATH', dirname(__FILE__) . '/'); // __DIR__
$tablepre = 'bbs_';
if (!$conf = include './conf/conf.php') {
	exit('请先安装完 Xiuno BBS 4.0。');
}
include './xiunophp/xiunophp.php';
include (APP_PATH . './model/thread.func.php');
include (APP_PATH . './model/post.func.php');
include (APP_PATH . './model/misc.func.php');
include (APP_PATH . './model/user.func.php');
include (APP_PATH . './model/forum.func.php');
include (APP_PATH . './model/mythread.func.php');
include (APP_PATH . './model/attach.func.php');
include (APP_PATH . './model/runtime.func.php');
$db = db_new($conf['db']);
!db_connect($db) AND exit('连接 4.0 数据库失败:' . $db->errstr);
$pass = isset($_POST['pass']) ? $_POST['pass'] : $_GET['pass'];
if ('123456' != $pass) {
	echo "err";
	exit;
}
$fid = isset($_POST['fid']) ? $_POST['fid'] : $_GET['fid']; // 版块 id
$uid = isset($_POST['uid']) ? $_POST['uid'] : $_GET['uid']; // 用户 id
$gid = isset($_POST['gid']) ? $_POST['gid'] : $_GET['gid']; // 用户组 id; 1: 管理员; 101:普通用户
$subject = isset($_POST['subject']) ? $_POST['subject'] : $_GET['subject'];
$message = isset($_POST['message']) ? $_POST['message'] : $_GET['message'];
$thread = array('fid' => $fid, 'uid' => $uid, 'subject' => $subject, 'doctype' => 0, 'message' => $message, 'time' => $time, 'longip' => $longip,);
$tid = thread_create($thread, $firstpid);
echo 'yes';
?>