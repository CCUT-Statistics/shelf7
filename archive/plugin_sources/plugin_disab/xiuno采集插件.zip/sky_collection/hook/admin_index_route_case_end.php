<?php exit;
//扩展后台路由
case 'collection': 	include _include(APP_PATH.'plugin/sky_collection/route/collection.php'); 	break;

?>