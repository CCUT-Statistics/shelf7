<?php exit;
//计划任务接口
case 'skycollection': include _include(APP_PATH.'plugin/sky_collection/crontab/thread.php'); break;

?>