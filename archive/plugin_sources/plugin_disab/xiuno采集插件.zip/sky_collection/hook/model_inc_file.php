<?php exit;
APP_PATH.'plugin/sky_collection/model/collection_node.func.php',
APP_PATH.'plugin/sky_collection/model/collection_history.func.php',
APP_PATH.'plugin/sky_collection/model/collection_content.func.php',
APP_PATH.'plugin/sky_collection/model/collection_crontab_log.func.php',
APP_PATH.'plugin/sky_collection/model/collection_attach.func.php',
?>