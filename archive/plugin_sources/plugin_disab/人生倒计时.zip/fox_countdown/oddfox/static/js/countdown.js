function Init_Countdown(){
    function getCountdown(){
        /* 当前时间戳 */
        let nowDate = +new Date();
        /* 今天开始时间戳 */
        let todayStartDate = new Date(new Date().toLocaleDateString()).getTime();
        /* 今天已经过去的时间 */
        let todayPassHours = (nowDate - todayStartDate) / 1000 / 60 / 60;
        /* 今天已经过去的时间比 */
        let todayPassHoursPercent = (todayPassHours / 24) * 100;
        $('#fox_countdown .day .title span').html(parseInt(todayPassHours));
        $('#fox_countdown .day .progress .progress-inner').css('width', parseInt(todayPassHoursPercent) + '%');
        $('#fox_countdown .day .progress .progress-percentage').html(parseInt(todayPassHoursPercent) + '%');
        /* 当前周几 */
        let weeks = {
            0: 7,
            1: 1,
            2: 2,
            3: 3,
            4: 4,
            5: 5,
            6: 6
        };
        let weekDay = weeks[new Date().getDay()];
        let weekDayPassPercent = (weekDay / 7) * 100;
        $('#fox_countdown .week .title span').html(weekDay);
        $('#fox_countdown .week .progress .progress-inner').css('width', parseInt(weekDayPassPercent) + '%');
        $('#fox_countdown .week .progress .progress-percentage').html(parseInt(weekDayPassPercent) + '%');
        let year = new Date().getFullYear();
        let date = new Date().getDate();
        let month = new Date().getMonth() + 1;
        let monthAll = new Date(year, month, 0).getDate();
        let monthPassPercent = (date / monthAll) * 100;
        $('#fox_countdown .month .title span').html(date);
        $('#fox_countdown .month .progress .progress-inner').css('width', parseInt(monthPassPercent) + '%');
        $('#fox_countdown .month .progress .progress-percentage').html(parseInt(monthPassPercent) + '%');
        let yearPass = (month / 12) * 100;
        $('#fox_countdown .year .title span').html(month);
        $('#fox_countdown .year .progress .progress-inner').css('width', parseInt(yearPass) + '%');
        $('#fox_countdown .year .progress .progress-percentage').html(parseInt(yearPass) + '%');
    }
    getCountdown();
    setInterval(() => {
        getCountdown();
    }, 1000*60*1);
}
Init_Countdown();