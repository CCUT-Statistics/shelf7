<?php !defined('DEBUG') AND exit('Forbidden');include _include(ADMIN_PATH.'view/htm/header.inc.htm');
    $num_pid = db_count('invite');
	$page = param(1,1);
	$data =  db_find('invite',array(), array('time'=>-1), $page, $pagesize = 20);
    $pagination = pagination(url("invite-{page}"), $num_pid, $page, $pagesize);
    function get_username($uid) {
        $u = user_read($uid);
        return isset($u) ?$u['username']:'';
    }
?>
 <div class="row"><div class="col-lg-10 mx-auto"><div class="card"><div class="card-body"><h3>批量生成邀请码</h3>
 <div class="input-group mb-3"><div class="input-group-prepend"><span class="input-group-text">生成数量</span></div>
 <input type="text" class="form-control" id="num" maxlength="2"></div><button type="submit" class="btn btn-primary btn-block" id="submit" data-loading-text="<?php echo lang('submiting');?>..."><?php echo lang('confirm');?></button></div></div><div class="card"><div class="card-body"><h3>导出</h3>
                 <a href="<?php echo url('invite_out'),'?type=csv&op=2&s=all';?>" target="_blank">导出邀请码(CSV)</a>&nbsp;&nbsp;<a href="<?php echo url('invite_out'),'?type=txt&op=2&s=all';?>" target="_blank">导出邀请码(TXT)</a><br>
                 <a href="<?php echo url('invite_out'),'?type=csv&op=2&s=un';?>" target="_blank">导出邀请码(CSV,未使用)</a>&nbsp;&nbsp;<a href="<?php echo url('invite_out'),'?type=txt&op=2&s=un';?>" target="_blank">导出邀请码(TXT,未使用)</a>
 </div></div><div class="card"><div class="card-body"><table class="table"><th>时间</th><th>使用者</th><th>邀请码</th><th>状态</th><th>编辑</th>
<?php foreach($data as $v){?><tr id="li<?php echo $v['code'];?>">
    <td><?php echo date('Y-m-d H:i:s',$v['time']);?></td><td><?php if($v['uid']!='0'){?><a href="/<?php echo url("user-$v[uid]");?>"><?php echo get_username($v['uid']);?></a><?php }else echo '-';?></td><td><?php echo $v['code'];?></td><td id="fli<?php echo $v['code'];?>"><?php echo $v['status']==1?'已使用':'未使用';?></td><td><button onclick="set(0,'<?php echo $v["code"];?>');">设为已使用</button><button onclick="set(1,'<?php echo $v["code"];?>');">设为未使用</button><button onclick="set(2,'<?php echo $v["code"];?>');">删除</button></td>
</tr><?php }?>
</table><nav class="text-center"><ul class="pagination"><?php echo $pagination; ?></ul></nav>
</div></div></div></div>
<?php include _include(ADMIN_PATH.'view/htm/footer.inc.htm');?>
<script>
    var jsubmit=$("#submit");var jinput = $("#num");
    jsubmit.on('click',function(){
        jsubmit.button('loading'); var postdata ="op=1&num="+jinput.val() ;
        $.xpost("<?php echo url('plugin-setting-tt_invite');?>",postdata,function(code,message) {
            $.alert(message); setTimeout(function(){location.reload();},3000);
        });
    });
    function set(opt,invite_code){//code 0:set-use 1:set-unuse 2:delete
        var status=$("#fli"+invite_code);var jtr=$("#li"+invite_code); var action=0;var postdata="op=2&code="+invite_code;
        if(opt==0){
            status.html('已使用'); postdata+='&act=0';
        } else if(opt==1){
            status.html('未使用');postdata+='&act=1';
        } else if(opt==2){
            jtr.fadeOut(); postdata+='&act=2';
        }
        $.xpost("<?php echo url('plugin-setting-tt_invite');?>",postdata,function(code,message){
            if(code!=0) $.alert(message);
        });
    }
</script>