<?php !defined('DEBUG') AND exit('Forbidden');include _include(ADMIN_PATH.'view/htm/header.inc.htm');
    $num_pid = db_count('promote_log');
	$page = param(1,1);
	$data =  db_find('promote_log',array(), array('time'=>-1), $page, $pagesize = 20);
    $pagination = pagination(url("promote_log-{page}"), $num_pid, $page, $pagesize);
    function get_username($uid) {
        $u = user_read($uid);
        return isset($u) ?$u['username']:'';
    }
?>
 <div class="row"><div class="col-lg-10 mx-auto"><div class="card"><div class="card-body"><table class="table"><th>时间</th><th>推广人</th><th>被推广人</th>
<?php foreach($data as $v){?><tr>
    <td><?php echo date('Y-m-d H:i:s',$v['time']);?></td><td><a href="/<?php echo url("user-$v[uid_from]"); ?>" ><?php echo get_username($v['uid_from']);?></a></td><td><a href="/<?php echo url("user-$v[uid_to]"); ?>" ><?php echo get_username($v['uid_to']);?></a></td>
</tr><?php }?></table><nav class="text-center"><ul class="pagination"><?php echo $pagination; ?></ul></nav>
</div></div></div></div>
<?php include _include(ADMIN_PATH.'view/htm/footer.inc.htm');?>