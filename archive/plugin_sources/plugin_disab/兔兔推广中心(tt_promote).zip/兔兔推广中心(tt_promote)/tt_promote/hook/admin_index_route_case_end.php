case 'promote_log': include APP_PATH.'plugin/tt_promote/admin_log.php'; break;
case 'promote_invite': include APP_PATH.'plugin/tt_promote/admin_invite.php'; break;