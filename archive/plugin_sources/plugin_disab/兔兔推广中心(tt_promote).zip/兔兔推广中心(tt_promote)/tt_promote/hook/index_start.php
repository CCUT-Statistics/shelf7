$setting_promote = setting_get('tt_promote');
if($setting_promote['visit_credits']!='0' || $setting_promote['visit_golds']!='0' || $setting_promote['visit_rmbs']!='0'){
    $promote_code = param('promote');
    $today0 = strtotime(date('Y-m-d',time()))-1;
    $r = db_count('promote_visit_log',array('ip'=>$longip,'time'=>array('>'=>$today0)));
    if($r<=0){
        $sql = db_find_one('user',array('promote'=>$promote_code));
        if(isset($sql)&&$sql['uid']!=$uid){
            db_insert('promote_visit_log',array('ip'=>$longip,'time'=>time(),'code'=>$promote_code));
            $uid = $sql['uid'];
            db_update('user',array('uid'=>$uid),array('credits+'=>$setting_promote['visit_credits'],'golds+'=>$setting_promote['visit_golds'],'rmbs+'=>$setting_promote['visit_rmbs']));
        }
    }
}