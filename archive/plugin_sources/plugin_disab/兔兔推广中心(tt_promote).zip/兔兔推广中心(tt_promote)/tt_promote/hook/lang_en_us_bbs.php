'promote'=>'Promote',
'promote_code'=>'Promote Code',
'please_input_promote'=>'Please Input Promote Code',
'promote_error'=>'Promote Wrong',