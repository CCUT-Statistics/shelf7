 'promote'=>'推广',
 'promote_code'=>'推广码',
 'please_input_promote'=>'请输入推广码',
 'promote_error'=>'推广码错误',