'promote'=>'推廣',
'promote_code'=>'推廣碼',
'please_input_promote'=>'請輸入推廣碼',
'promote_error'=>'推廣碼錯誤',