elseif($action == 'promote') {
    if($method == 'GET')
        include _include(APP_PATH.'plugin/tt_promote/view/htm/my_promote.htm');
    elseif($method == 'POST') {

    }
}