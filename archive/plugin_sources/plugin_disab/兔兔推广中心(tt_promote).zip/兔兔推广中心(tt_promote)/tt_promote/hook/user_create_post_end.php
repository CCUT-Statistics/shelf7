if($add_credits&&isset($promote_code)) {
user_update($uid,array('credits+'=>$setting_promote['bonus_credits_to'],'golds+'=>$setting_promote['bonus_golds_to'],'rmbs+'=>$setting_promote['bonus_rmbs_to']));
$r = db_find_one('user',array('promote'=>$promote_code));
$from_uid = $r['uid'];
user_update($from_uid,array('credits+'=>$setting_promote['bonus_credits_from'],'golds+'=>$setting_promote['bonus_golds_from'],'rmbs+'=>$setting_promote['bonus_rmbs_from']));
db_insert('promote_log',array('time'=>time(),'uid_from'=>$from_uid,'uid_to'=>$uid));
}