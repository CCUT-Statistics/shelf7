$promote_code = param('promote_code');$add_credits=0;
$setting_promote = setting_get('tt_promote');
$must_code = $setting_promote['must_code'];
if($must_code) {
    if(strlen($promote_code)!=6) message('promote_code', lang('please_input_promote'));
    $query = db_count('user',array('promote'=>$promote_code));
    if($query<=0) message('promote_code', lang('promote_error').'1');
    $add_credits=1;
} elseif($must_code=='0'&&isset($promote_code)&&strlen($promote_code)==6) {
    $query = db_count('user',array('promote'=>$promote_code));
    if($query<=0) message('promote_code', lang('promote_error').'2');
    $add_credits=1;
}