<?php
!defined('DEBUG') AND exit('Forbidden');
$tablepre = $db->tablepre;
$sql = "ALTER TABLE ".$tablepre."user ADD promote CHAR(64) NOT NULL DEFAULT '0';";
db_exec($sql);

$sql="CREATE TABLE IF NOT EXISTS `{$tablepre}promote_log` (
  `proid` int(10) NOT NULL AUTO_INCREMENT,
  `uid_from` int(10) NOT NULL,
  `uid_to` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (proid),					# 
	KEY (proid),						# 
	UNIQUE KEY (proid)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;";
db_exec($sql);

$sql="CREATE TABLE IF NOT EXISTS `{$tablepre}promote_visit_log` (
  `vid` int(10) NOT NULL AUTO_INCREMENT,
  `ip` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  `code` CHAR(10) NOT NULL,
  PRIMARY KEY (vid),					# 
	KEY (vid),						# 
	UNIQUE KEY (vid)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;";
db_exec($sql);

setting_set('tt_promote',array('must_code'=>0,'bonus_credits_from'=>1,'bonus_golds_from'=>1,'bonus_rmbs_from'=>0,'bonus_credits_to'=>1,'bonus_golds_to'=>1,'bonus_rmbs_to'=>0,'visit_credits'=>0,'visit_golds'=>0,'visit_rmbs'=>0));

?>