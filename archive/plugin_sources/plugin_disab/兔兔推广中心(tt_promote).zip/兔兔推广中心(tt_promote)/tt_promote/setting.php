<?php !defined('DEBUG') AND exit('Access Denied.');
$action = param(3);
if(empty($action)) {
    if ($method == 'GET')
        include _include(APP_PATH . 'plugin/tt_promote/setting.htm');
    elseif($method=='POST')
    {
        $op=param('op');
        if($op==0){
            $set = setting_get('tt_promote');
            $update_list = array();
            foreach ($set as $k => $v)
                $update_list[$k] = param($k);
            setting_set('tt_promote', $update_list);
            message(0, '设置成功!');
        }
    }
}
?>