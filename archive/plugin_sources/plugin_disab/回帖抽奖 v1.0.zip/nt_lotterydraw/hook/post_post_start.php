<?php exit;

if($thread['is_lucky_thread']) {
	$pidarr = db_find('post', array('tid'=>$tid), array(), 1, 10000, '', array('pid', 'uid'));
	foreach($pidarr as $arr) {
		if($arr['uid'] == $uid && $gid != 1) {
			message(-1, '此活动只能参加一次');
		}
	}

	if($thread['posts'] >= 50) {
		message(-1, '活动参加人数已满');
	}

}
?>