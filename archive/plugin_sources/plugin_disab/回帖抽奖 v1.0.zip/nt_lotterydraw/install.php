<?php

!defined('DEBUG') AND exit('Forbidden');


$tablepre = $db->tablepre;
$sql = "ALTER TABLE {$tablepre}thread ADD COLUMN is_lucky_thread tinyint(3) NOT NULL default '0'";
db_exec($sql);

$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}thread_lucky_post (
	tid int(11) unsigned NOT NULL default '0',
	pids text NOT NULL DEFAULT '',
	success_template text NOT NULL DEFAULT '',
	PRIMARY KEY (tid)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8";

$r = db_exec($sql);
$r === FALSE AND message(-1, '创建表结构失败'); 
?>