<?php

!defined('DEBUG') AND exit('Forbidden');

$tablepre = $db->tablepre;
$sql = "ALTER TABLE {$tablepre}thread DROP COLUMN is_lucky_thread";
db_exec($sql);

$sql = "DROP TABLE IF EXISTS {$tablepre}thread_lucky_post;";
$r = db_exec($sql);
$r === FALSE AND message(-1, '创建表结构失败'); 



?>