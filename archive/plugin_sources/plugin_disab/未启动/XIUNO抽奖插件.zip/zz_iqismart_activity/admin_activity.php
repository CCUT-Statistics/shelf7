<?php !defined('DEBUG') AND exit('Forbidden');include _include(ADMIN_PATH.'view/htm/header.inc.htm');
    $total = db_count('iqismart_activity');
	$page = param(1,1);
	$data =  db_find('iqismart_activity',array(), array('id'=>-1), $page, $pagesize = 20);
	$pagination = pagination(url("zz_iqismart_activity-{page}"), $total, $page, $pagesize);

?>
<div class="row">
    <div class="col-lg-10 mx-auto">
      	<div class="card"><div class="card-body" >
          <a href="<?php echo url("zz_iqismart_product");?>"><h3 style="display:inline">商品列表</h3></a> 
          <a href="<?php echo url("zz_iqismart_product_add");?>"><h3 style="display:inline">添加商品</h3></a> 
          <a href="<?php echo url("zz_iqismart_activity");?>"><h3 style="display:inline">活动列表</h3></a>
          <a href="<?php echo url("zz_iqismart_activity_add");?>"><h3 style="display:inline">创建活动</h3></a>
          <a href="<?php echo url("zz_iqismart_activity_order");?>"><h3 style="display:inline">订单列表</h3></a>
          </div>
      	</div> 
        <div class="card">
          	 <div class="card-header">商品列表</div>
            <div class="card-body">
                <table class="table">
                  	<!--  
                     `name` varchar(50) DEFAULT '' COMMENT '活动名称', 
                      `start_date` int(11)  DEFAULT NULL COMMENT '开始时间',
                      `end_date` int(11)  DEFAULT NULL COMMENT '结束时间',
                      `show_user_count` int(11)  DEFAULT NULL COMMENT '是否显示参数人数',
                      `max_user_count` int(11)  DEFAULT NULL COMMENT '参数人数限制',
                      `description` varchar(200) DEFAULT '' COMMENT '活动说明',
                      `use_type` int(1) DEFAULT '' COMMENT '消耗积分类型0金币 1人民币',
                      `use_num` int(11) DEFAULT '' COMMENT '消耗积分数量',
                      `only_vip` int(11)  DEFAULT NULL COMMENT '仅vip用户参与',
                      `times_limit` int(11)  DEFAULT NULL COMMENT '总参与次数限制',
                      `times_limit_day` int(11)  DEFAULT NULL COMMENT '每日参与次数限制',
                    -->
                    <tr>
                        <th>ID</th>
                        <th>活动名称</th> 
                        <th>开始时间</th>
                      	<th>结束时间</th> 
                        <th>创建时间</th>
                      	<th>操作</th>
                    </tr>
                    <?php foreach($data as $v){ ?>
                    <tr>
                        <td><?php echo $v['id'];?></td> 
                      	<td><?php echo $v['name'];?></td> 
                        <td><?php echo date('Y-m-d H:i:s',$v['start_date']); ?></td>
                      	<td><?php echo date('Y-m-d H:i:s',$v['end_date']); ?></td> 
                        <td><?php echo date('Y-m-d H:i:s',$v['create_date']); ?></td>
                     	<td> <button class='btn btn-primary btn-sm' onclick="edit('<?php echo $v['id'];?>')">修改</button> <button class='btn btn-danger btn-sm' onclick="del('<?php echo $v['id'];?>')">删除</button></td>
                    </tr>
                    <?php }?></table>
                <nav class="text-center">
                    <ul class="pagination"><?php echo $pagination; ?></ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<?php include _include(ADMIN_PATH.'view/htm/footer.inc.htm');?>
<script>
  function edit(id){
    location.href = xn.url('zz_iqismart_activity_add')+'?id='+id;
  }
  
  function del(id){
     var  postdata = "op=activity_del&pid="+id;
   	 $.xpost('<?php echo url("plugin-setting-zz_iqismart_activity");?>', postdata, function (code, message) {
            if (code == 0) {
                $.alert(message);
              	setTimeout(function(){location.reload();},2000) 
            } else {
                $.alert(message); 
            }
        });
  }
</script>