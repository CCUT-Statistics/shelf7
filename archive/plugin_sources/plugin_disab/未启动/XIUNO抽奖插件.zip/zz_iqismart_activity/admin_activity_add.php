 <?php !defined('DEBUG') AND exit('Forbidden');include _include(ADMIN_PATH.'view/htm/header.inc.htm');?>
<?php
$activity;
if(!empty($_GET['id'])){
	 $activity = db_find_one('iqismart_activity',array('id'=>$_GET['id'])); 
}
?>
<div class="row">
    <div class="col-lg-10 mx-auto">
      	<div class="card"><div class="card-body" >
          <a href="<?php echo url("zz_iqismart_product");?>"><h3 style="display:inline">商品列表</h3></a> 
          <a href="<?php echo url("zz_iqismart_product_add");?>"><h3 style="display:inline">添加商品</h3></a> 
          <a href="<?php echo url("zz_iqismart_activity");?>"><h3 style="display:inline">活动列表</h3></a>
          <a href="<?php echo url("zz_iqismart_activity_add");?>"><h3 style="display:inline">创建活动</h3></a>
          <a href="<?php echo url("zz_iqismart_activity_order");?>"><h3 style="display:inline">订单列表</h3></a>
          </div>
      	</div> 
        <div class="card">
            <div class="card-body">
                <!--  
				 `name` varchar(50) DEFAULT '' COMMENT '活动名称', 
                  `start_date` int(11)  DEFAULT NULL COMMENT '开始时间',
                  `end_date` int(11)  DEFAULT NULL COMMENT '结束时间',
                  `show_user_count` int(11)  DEFAULT NULL COMMENT '是否显示参数人数',
                  `max_user_count` int(11)  DEFAULT NULL COMMENT '参数人数限制',
                  `description` varchar(200) DEFAULT '' COMMENT '活动说明',
                  `use_type` int(1) DEFAULT '' COMMENT '消耗积分类型0金币 1人民币',
                  `use_num` int(11) DEFAULT '' COMMENT '消耗积分数量',
                  `only_vip` int(11)  DEFAULT NULL COMMENT '仅vip用户参与',
                  `times_limit` int(11)  DEFAULT NULL COMMENT '总参与次数限制',
                  `times_limit_day` int(11)  DEFAULT NULL COMMENT '每日参与次数限制',
				-->
                <h3>创建活动</h3>
                <form action="<?php echo url("plugin-setting-zz_iqismart_activity");?>" method="post" id="form">
                  <input  type="hidden" name="id" value="<?php if(!empty($activity)) echo $activity['id']?>"/>
                <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">名称</span></div>
                    <input class="form-control" name="name" value="<?php if(!empty($activity)) echo $activity['name']?>" /></div> 
                  <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">活动说明</span></div>
                    <textarea class="form-control" name="description"  rows='5' ><?php if(!empty($activity)) echo $activity['description']?></textarea>
                  </div> 
                 <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">开始时间</span></div>
                  	<input class="form-control" type="date" id="create_date_start" name="create_date_start" placeholder="开始时间" value="<?php echo date('Y-m-d',$activity['start_date']); ?>">  
                  </div>  
                  <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">结束时间</span></div>
                  	<input class="form-control" type="date" id="create_date_end" name="create_date_end" placeholder="结束时间" value="<?php echo date('Y-m-d',$activity['end_date']); ?>">  
                  </div>  
                  <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">显示参数人数</span></div>
                    <input class="form-control" name="show_user_count" value="<?php if(!empty($activity)) echo $activity['show_user_count']?>" />
                  </div> 
                
                  <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">参数人数限制</span></div>
                    <input class="form-control" name="max_user_count" value="<?php if(!empty($activity)) echo $activity['max_user_count']?>" />
                  </div> 
                   <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">仅vip用户参与</span></div>
                    <input class="form-control" name="only_vip" value="<?php if(!empty($activity)) echo $activity['only_vip']?>" />
                  </div> 
                  
                    <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">总参与次数限制</span></div>
                    <input class="form-control" name="times_limit" value="<?php if(!empty($activity)) echo $activity['times_limit']?>" />
                  </div> 
                    <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">每日参与次数限制</span></div>
                    <input class="form-control" name="times_limit_day" value="<?php if(!empty($activity)) echo $activity['times_limit_day']?>" />
                  </div> 
                  
                   <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">消耗积分类型</span></div>
                    <select name="use_type">
                        <option value="0" <?php if(!empty($activity) && $activity['use_type']==0) echo 'selected'?> >金币</option>
                        <option value="1" <?php if(!empty($activity) && $activity['use_type']==1) echo 'selected'?>>人民币(分)</option>
                    </select>
                  </div>
                    <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">消耗积分数量</span></div>
                    <input class="form-control" name="use_num" value="<?php if(!empty($activity)) echo $activity['use_num']?>" />
                  </div> 
                  
                  <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">奖品设置</span></div>
                    <input class="form-control" name="pid1" value="<?php if(!empty($activity)) echo $activity['pid1']?>" placeHolder='奖品1的商品ID' />
                    <input class="form-control" name="pid2" value="<?php if(!empty($activity)) echo $activity['pid2']?>" placeHolder='奖品2的商品ID' />
                    <input class="form-control" name="pid3" value="<?php if(!empty($activity)) echo $activity['pid3']?>" placeHolder='奖品3的商品ID' />
                    <input class="form-control" name="pid4" value="<?php if(!empty($activity)) echo $activity['pid4']?>" placeHolder='奖品4的商品ID' />
                    <input class="form-control" name="pid5" value="<?php if(!empty($activity)) echo $activity['pid5']?>" placeHolder='奖品5的商品ID' />
                    <input class="form-control" name="pid6" value="<?php if(!empty($activity)) echo $activity['pid6']?>" placeHolder='奖品6的商品ID' />
                  </div> 
                  <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">中奖概率</span></div>
                    <input class="form-control" name="percent1" value="<?php if(!empty($activity)) echo $activity['percent1']?>" placeHolder='中奖率1的商品ID' />
                    <input class="form-control" name="percent2" value="<?php if(!empty($activity)) echo $activity['percent2']?>" placeHolder='中奖率2的商品ID' />
                    <input class="form-control" name="percent3" value="<?php if(!empty($activity)) echo $activity['percent3']?>" placeHolder='中奖率3的商品ID' />
                    <input class="form-control" name="percent4" value="<?php if(!empty($activity)) echo $activity['percent4']?>" placeHolder='中奖率4的商品ID' />
                    <input class="form-control" name="percent5" value="<?php if(!empty($activity)) echo $activity['percent5']?>" placeHolder='中奖率5的商品ID' />
                    <input class="form-control" name="percent6" value="<?php if(!empty($activity)) echo $activity['percent6']?>" placeHolder='中奖率6的商品ID' />
                  </div> 
                  
                
                <button type="submit" class="btn btn-success btn-block" id="submit"
                        data-loading-text="<?php echo lang('submiting');?>..."><?php echo lang('confirm');?></button>
                  <a href="<?php echo url('zz_iqismart_activity');?>">查看活动列表</a>
                </form></div>
        </div>
        
    </div>
</div>
<?php include _include(ADMIN_PATH.'view/htm/footer.inc.htm');?>
<script>
    var jform = $("#form");
    var jsubmit = $("#submit");
    var jupgrade = $("#upgrade");
    var jup_username = $("#up_username");
    jform.on('submit', function () {
        jform.reset();
        jsubmit.button('loading');
        var postdata = jform.serialize();
        postdata += "&op=activity_add";
        $.xpost(jform.attr('action'), postdata, function (code, message) {
            if (code == 0) {
                 $.alert(message);
                jsubmit.button('reset');
            } else {
                $.alert(message);
                jsubmit.button('reset');
            }
        });
        return false;
    });
     
</script>