 <?php !defined('DEBUG') AND exit('Forbidden');include _include(ADMIN_PATH.'view/htm/header.inc.htm');?>
<?php
$product;
if(!empty($_GET['id'])){
	 $product = db_find_one('iqismart_product',array('id'=>$_GET['id'])); 
}
?>
<div class="row">
    <div class="col-lg-10 mx-auto">
      	<div class="card"><div class="card-body" >
          <a href="<?php echo url("zz_iqismart_product");?>"><h3 style="display:inline">商品列表</h3></a> 
          <a href="<?php echo url("zz_iqismart_product_add");?>"><h3 style="display:inline">添加商品</h3></a> 
          <a href="<?php echo url("zz_iqismart_activity");?>"><h3 style="display:inline">活动列表</h3></a>
          <a href="<?php echo url("zz_iqismart_activity_add");?>"><h3 style="display:inline">创建活动</h3></a>
          <a href="<?php echo url("zz_iqismart_activity_order");?>"><h3 style="display:inline">订单列表</h3></a>
          </div>
      	</div> 
        <div class="card">
            <div class="card-body">
                <!-- `name` varchar(50) DEFAULT '' COMMENT '商品名称',
  `type` int(11) DEFAULT NULL COMMENT '商品类型：0金币 1人民币 2主题 3vip会员 4实物 ',
  `code` varchar(50) DEFAULT NULL COMMENT '数量、主题ID、会员月份',	-->
                <h3>添加商品</h3>
                <form action="<?php echo url("plugin-setting-zz_iqismart_activity");?>" method="post" id="form">
                  <input  type="hidden" name="id" value="<?php if(!empty($product)) echo $product['id']?>"/>
                <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">名称</span></div>
                    <input class="form-control" name="name" value="<?php if(!empty($product)) echo $product['name']?>" /></div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">类型</span></div>
                    <select name="type">
                        <option value="0" <?php if(!empty($product) && $product['type']==0) echo 'selected'?> >金币</option>
                        <option value="1" <?php if(!empty($product) && $product['type']==1) echo 'selected'?>>人民币</option>
                        <option value="2" <?php if(!empty($product) && $product['type']==2) echo 'selected'?>>主题</option>
                        <option value="3" <?php if(!empty($product) && $product['type']==3) echo 'selected'?>>vip会员</option>
                        <option value="4" <?php if(!empty($product) && $product['type']==4) echo 'selected'?>>实物</option>
                      	<option value="5" <?php if(!empty($product) && $product['type']==5) echo 'selected'?>>谢谢参与</option>
                    </select>
                  </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend"><span class="input-group-text">金币/人民币数量、主题ID、会员天数</span></div>
                    <input class="form-control" name="code" value="<?php if(!empty($product)) echo $product['code']?>"/></div>
                <button type="submit" class="btn btn-success btn-block" id="submit"
                        data-loading-text="<?php echo lang('submiting');?>..."><?php echo lang('confirm');?></button>
                  <a href="<?php echo url('zz_iqismart_product');?>">查看商品列表</a>
                </form></div>
        </div>
        
    </div>
</div>
<?php include _include(ADMIN_PATH.'view/htm/footer.inc.htm');?>
<script>
    var jform = $("#form");
    var jsubmit = $("#submit");
    var jupgrade = $("#upgrade");
    var jup_username = $("#up_username");
    jform.on('submit', function () {
        jform.reset();
        jsubmit.button('loading');
        var postdata = jform.serialize();
        postdata += "&op=product_add";
        $.xpost(jform.attr('action'), postdata, function (code, message) {
            if (code == 0) {
                 $.alert(message);
                jsubmit.button('reset');
            } else {
                $.alert(message);
                jsubmit.button('reset');
            }
        });
        return false;
    });
     
</script>