case 'zz_iqismart_product': include APP_PATH.'plugin/zz_iqismart_activity/admin_product.php'; break;
case 'zz_iqismart_product_add': include APP_PATH.'plugin/zz_iqismart_activity/admin_product_add.php'; break;
case 'zz_iqismart_activity': include APP_PATH.'plugin/zz_iqismart_activity/admin_activity.php'; break;
case 'zz_iqismart_activity_add': include APP_PATH.'plugin/zz_iqismart_activity/admin_activity_add.php'; break;
case 'zz_iqismart_activity_order': include APP_PATH.'plugin/zz_iqismart_activity/admin_activity_order.php'; break;