case 'prize': include _include(APP_PATH.'plugin/zz_iqismart_activity/route/prize.php'); break;
case 'activity': include _include(APP_PATH.'plugin/zz_iqismart_activity/route/activity.php'); break;