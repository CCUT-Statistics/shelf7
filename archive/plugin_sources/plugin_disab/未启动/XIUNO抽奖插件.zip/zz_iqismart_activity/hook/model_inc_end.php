include _include(APP_PATH.'plugin/zz_iqismart_activity/model/activity.func.php');
