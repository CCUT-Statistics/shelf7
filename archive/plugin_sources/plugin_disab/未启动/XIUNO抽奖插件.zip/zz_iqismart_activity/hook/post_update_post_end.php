<?php exit;
if ($activity_id>=0){ 
    db_update('thread', array('tid' => $tid), array('activity_id' =>$activity_id));
}
?>