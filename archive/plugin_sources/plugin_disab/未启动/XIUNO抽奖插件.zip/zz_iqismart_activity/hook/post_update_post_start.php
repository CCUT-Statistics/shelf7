<?php exit;
$activity_id = param('activity_id',0);
if($activity_id<0){message(-1,'输入数字不合法！不能为负。');die();}
if ($activity_id>0){
    $activity = db_find_one('iqismart_activity',array('id'=>$activity_id));
  	if(empty($activity)){
    	message(-1,'活动不存在。');die();
    } 
    
}
?>