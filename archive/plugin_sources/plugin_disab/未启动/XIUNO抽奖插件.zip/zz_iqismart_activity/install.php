<?php
!defined('DEBUG') AND exit('Forbidden');
$tablepre = $db->tablepre;
 
$sql = "ALTER TABLE ".$tablepre."thread ADD activity_id INT(20) NOT NULL default '0';";
db_exec($sql);

#活动表
$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}iqismart_activity (
  `id` int(11)  NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) DEFAULT '' COMMENT '活动名称',
  `create_date` int(11)  DEFAULT NULL COMMENT '创建时间',
  `start_date` int(11)  DEFAULT NULL COMMENT '开始时间',
  `end_date` int(11)  DEFAULT NULL COMMENT '结束时间',
  `show_user_count` int(11)  DEFAULT NULL COMMENT '是否显示参数人数',
  `max_user_count` int(11)  DEFAULT NULL COMMENT '参数人数限制',
  `description` varchar(200) DEFAULT '' COMMENT '活动说明',
  `use_type` int(1) DEFAULT 0 COMMENT '消耗积分类型',
  `use_num` int(11) DEFAULT 0 COMMENT '消耗积分数量',
  `only_vip` int(11)  DEFAULT NULL COMMENT '仅vip用户参与',
  `times_limit` int(11)  DEFAULT NULL COMMENT '总参与次数限制',
  `times_limit_day` int(11)  DEFAULT NULL COMMENT '每日参与次数限制',
  
   `pid6` int(11)  DEFAULT 0 COMMENT '奖品6的商品ID ',
   `pid1` int(11)  DEFAULT 0 COMMENT '奖品1的商品ID',
   `pid2` int(11)  DEFAULT 0 COMMENT '奖品2的商品ID',
   `pid3` int(11)  DEFAULT 0 COMMENT '奖品3的商品ID',
   `pid4` int(11)  DEFAULT 0 COMMENT '奖品4的商品ID',
   `pid5` int(11)  DEFAULT 0 COMMENT '奖品5的商品ID',
   `percent6` int(11)  DEFAULT 0 COMMENT '6',
   `percent1` int(11)  DEFAULT 0 COMMENT '中奖率1',
   `percent2` int(11)  DEFAULT 0 COMMENT '中奖率2',
   `percent3` int(11)  DEFAULT 0 COMMENT '中奖率3',
   `percent4` int(11)  DEFAULT 0 COMMENT '中奖率4',
   `percent5` int(11)  DEFAULT 0 COMMENT '中奖率5',
   
  PRIMARY KEY (`id`)
  
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
$r = db_exec($sql);
 
#商品表
$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}iqismart_product (
  `id` int(11) AUTO_INCREMENT NOT NULL COMMENT 'ID',
  `name` varchar(50) DEFAULT '' COMMENT '商品名称',
  `type` int(11) DEFAULT NULL COMMENT '商品类型：0金币 1人民币 2主题 3vip会员 4实物 ',
  `code` varchar(50) DEFAULT NULL COMMENT '数量、主题ID、会员月份',	
  `create_date` int(11)  DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) 
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
$r = db_exec($sql);
 

#奖励表
$sql = "CREATE TABLE IF NOT EXISTS {$tablepre}iqismart_activity_order (
  `id` int(11) AUTO_INCREMENT NOT NULL COMMENT 'ID',
  `uid` int(10) DEFAULT 0 COMMENT 'uid',
  `aid` int(10) DEFAULT 0 COMMENT '活动iD',
  `pid` int(11) DEFAULT NULL COMMENT '商品ID ', 
  `code` varchar(50) DEFAULT '' COMMENT '数量、主题ID、会员月份、实物兑换码',	
  `create_date` int(11)  DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)  
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
$r = db_exec($sql);
 
 
setting_set('zz_iqismart_activity',array('test'=>1));
?>