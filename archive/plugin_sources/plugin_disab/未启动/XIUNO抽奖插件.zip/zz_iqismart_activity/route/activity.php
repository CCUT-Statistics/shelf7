<?php

!defined('DEBUG') AND exit('Forbidden');

if($method == 'GET'){
  	if(!empty($_GET['single'])){
    	include _include(APP_PATH.'plugin/zz_iqismart_activity/htm/activity-single.htm'); 
    }else{
		include _include(APP_PATH.'plugin/zz_iqismart_activity/htm/activity.htm'); 
    }
}else{
  $gettype = $_POST['op'];
  if($gettype=='status') {
    $aid = $_POST['id'];
    //if(empty($user)) {message(-1,'请先登录');die;}
    message(0, xn_json_encode(getStatus($aid,$user['uid'])));

  } elseif($gettype=='prize') {
     $aid = $_POST['id'];
     if(empty($user)) {message(-1,'请先登录');die;}
     message(0, xn_json_encode(doPrize($aid,$user['uid']))); 
  }
}

 
?>