<?php

!defined('DEBUG') AND exit('Forbidden');

if($method == 'GET'){
	include _include(APP_PATH.'plugin/zz_iqismart_prize/htm/prize.htm'); 
}else{
  
}

 
?>