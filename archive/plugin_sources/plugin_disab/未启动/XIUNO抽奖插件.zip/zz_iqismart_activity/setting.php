<?php

!defined('DEBUG') AND exit('Access Denied.');

$action = param(3);
if(empty($action)){
    if($method == 'GET'){//设置页面
        include _include(APP_PATH.'plugin/zz_iqismart_activity/setting.htm');
    } elseif($method=="POST") {
        $gettype = param('op');
        if($gettype=='product_add') {
          	$id = param('id');
            $name = param('name');$type = param('type');$code = param('code');
            $db_array;
          	if(empty($id)){
            	db_insert('iqismart_product', array('name' => $name,'type' => $type,'code' => $code,'create_date'=>time())); 
              	 message(0, '添加成功');
            }else{
            	db_update('iqismart_product',array('id'=>$id), array('name' => $name,'type' => $type,'code' => $code,'create_date'=>time())); 
              	 message(0, '修改成功');
            }
           
        } elseif($gettype=='product_del') {
          	$id = param('pid');
          	if(empty($id))  {message(-1, 'id不能为空');die;} 
          	db_delete('iqismart_product',array('id'=>$id));
            message(0, '删除成功');
           
        }elseif($gettype=='activity_add') {
           /*
				 `name` varchar(50) DEFAULT '' COMMENT '活动名称', 
                  `start_date` int(11)  DEFAULT NULL COMMENT '开始时间',
                  `end_date` int(11)  DEFAULT NULL COMMENT '结束时间',
                  `show_user_count` int(11)  DEFAULT NULL COMMENT '是否显示参数人数',
                  `max_user_count` int(11)  DEFAULT NULL COMMENT '参数人数限制',
                  `description` varchar(200) DEFAULT '' COMMENT '活动说明',
                  `use_type` int(1) DEFAULT '' COMMENT '消耗积分类型0金币 1人民币',
                  `use_num` int(11) DEFAULT '' COMMENT '消耗积分数量',
                  `only_vip` int(11)  DEFAULT NULL COMMENT '仅vip用户参与',
                  `times_limit` int(11)  DEFAULT NULL COMMENT '总参与次数限制',
                  `times_limit_day` int(11)  DEFAULT NULL COMMENT '每日参与次数限制',
				 */
          	$id = param('id');
            $name = param('name');
          	$start_date = strtotime(param('create_date_start'));
          	$end_date = strtotime(param('create_date_end'));
            $show_user_count = param('show_user_count',0);
          	$max_user_count = param('max_user_count',0);
          	$description = param('description');
          	$use_type = param('use_type',0);
          	$use_num = param('use_num',0);
          	$only_vip = param('only_vip',0);
          	$times_limit = param('times_limit',0);
          	$times_limit_day = param('times_limit_day',0);
          	$pid1 = param('pid1');
          	$pid2 = param('pid2');
          	$pid3 = param('pid3');
          	$pid4 = param('pid4');
          	$pid5 = param('pid5');
          	$pid6 = param('pid6');
          	$percent1 = param('percent1');
          	$percent2 = param('percent2');
          	$percent3 = param('percent3');
          	$percent4 = param('percent4');
          	$percent5 = param('percent5');
          	$percent6 = param('percent6');
          
          	if(empty($start_date)){ message(-1, '开始时间不正确');die;  }
          	if(empty($end_date)){ message(-1, '开始时间不正确');die;  }
          	if(empty($description)){ message(-1, '描述不能为空');die;  }
          	if(empty($name)){ message(-1, '名称不能为空');die;  }
          	if(empty($pid1)){ message(-1, '奖品1必须设置');die;  }
          	if(empty($pid2)){ message(-1, '奖品2必须设置');die;  }
          	if(empty($pid3)){ message(-1, '奖品3必须设置');die;  }
          	if(empty($pid4)){ message(-1, '奖品4必须设置');die;  }	
          	if(empty($pid5)){ message(-1, '奖品5必须设置');die;  }
            if(empty($pid6)){ message(-1, '奖品6必须设置');die;  }
            if(empty($percent1) || $percent1<1){ message(-1, '中奖率1必须设置');die;  }
          	if(empty($percent2) || $percent2<1){ message(-1, '中奖率2必须设置');die;  }
          	if(empty($percent3) || $percent3<1){ message(-1, '中奖率3必须设置');die;  }
          	if(empty($percent4) || $percent4<1){ message(-1, '中奖率4必须设置');die;  }	
          	if(empty($percent5) || $percent5<1){ message(-1, '中奖率5必须设置');die;  }
          	if(empty($percent6) || $percent6<1){ message(-1, '中奖率6必须设置');die;  }
          
            $update_array = array('name' => $name,
                                                     'start_date' => $start_date,
                                                     'end_date' => $end_date,
                                                     'show_user_count' => $show_user_count,
                                                     'max_user_count' => $max_user_count,
                                                     'description' => $description,
                                                     'use_type' => $use_type,
                                                     'use_num' => $use_num,
                                                     'only_vip' => $only_vip,
                                                     'times_limit' => $times_limit,
                                  					 'times_limit_day' => $times_limit_day,
                                                     'pid1' => $pid1,
                                                     'pid2' => $pid2,
                                                     'pid3' => $pid3,
                                                     'pid4' => $pid4,
                                                     'pid5' => $pid5,
                                                     'pid6' => $pid6,
                                  					 'percent1' => $percent1,
                                                     'percent2' => $percent2,
                                                     'percent3' => $percent3,
                                                     'percent4' => $percent4,
                                                     'percent5' => $percent5,
                                  						'percent6' => $percent6,
                                                     'create_date'=>time());
          	if(empty($id)){
            	db_insert('iqismart_activity',$update_array); 
              	 message(0, '添加成功');
            }else{
            	db_update('iqismart_activity',array('id'=>$id),$update_array); 
              	 message(0, '修改成功');
            }
           
        } elseif($gettype=='activity_del') {
          	$id = param('pid');
          	if(empty($id))  {message(-1, 'id不能为空');die;} 
          	db_delete('iqismart_activity',array('id'=>$id));
            message(0, '删除成功');
           
        } elseif($gettype=='4') {
            $username = param('username');
            $user = db_find_one('user', array('username' => $username));
            $now_user_array = array("exp" => $user['credits'], "golds" => $user['golds'], "rmbs" => $user['rmbs']);
            message("0", $now_user_array);
        } elseif($gettype=='1') {
            $_uid = param('_useruid'); $_tid = param('_tid');
            db_insert('paylist',array('tid' => $_tid, 'uid' => $_uid, 'num'=>0,'credit_type'=>1, 'type' => 1, 'paytime' => time()));
            message("0","操作成功");
        } elseif ($gettype=='2') {
            $update_lists=param('sell_group',array(0)); $status=0;
            if(empty($update_lists))
                message(-1, '设置失败！');
            $tablepre = $db->tablepre;
            $sql = 'UPDATE '.$tablepre.'group SET allowsell="0";';
            foreach($update_lists as $k => $v)
                $sql .= 'UPDATE '.$tablepre.'group SET allowsell="1" WHERE gid="'.$k.'";';
            db_exec($sql);
            group_list_cache_delete();
            message(0, '设置成功！');
        } elseif ($gettype=='3') {
            $settings = array();
            foreach($g_credits_item_array as $set)
                $settings[$set] = param($set);
            $settings['limit']  = param('limit');
            $settings['min']  = param('min');
            $settings['convert_exchange']=param('convert_exchange')=='convert_exchange'?'1':'0';
            $settings['exchange_n']=param('exchange_n','1');
            $settings['exchange_c']=param('exchange_c','1');
            setting_set('tt_credits',$settings);
            message(0, '设置成功！');
        } elseif($gettype=='5') {
            $credit = param('d_credit');$gold=param('d_gold');$rmb=param('d_rmb');
            $tablepre = $db->tablepre;
            $sql="alter table {$tablepre}user alter column credits set default ".$credit.";";
            db_exec($sql);
            $sql="alter table {$tablepre}user alter column golds set default ".$gold.";";
            db_exec($sql);
            $sql="alter table {$tablepre}user alter column rmbs set default ".$rmb.";";
            db_exec($sql);
            message(0, '设置成功！');
        } elseif($gettype=='6') {
            $username = param('username','');
            if(empty($username)) {message(-1, 'ERROR');die();}
            $user = db_find_one('user',array('username'=>$username));
            user_update_group($user['uid']);
            message(0,'设置成功！');
        }
    }
}
	
?>