<?php
/*
* Copyright (C) 2022
*/

!defined('DEBUG') AND exit('Access Denied.');

include _include(APP_PATH.'plugin/qg_thread_poster/service/inc/imgCompress.class.php');
if($method == 'POST') {
    $tid = param('tid'); 
    $header = G('header');
    $sitename = $header['title'];
    $introduction = $header['description'];
    
    $thread_info = db_find_one('thread', ['tid'=>$tid],[],['subject', 'create_date','uid']);
    if ($thread_info) {
        $post_info = db_find_one('post', ['tid'=>$tid],[],['message']);
        if(!$post_info) {
            exit(json_encode(array('code'=>-1,'msg'=>'内容错误')));
        }
    } else {
        exit(json_encode(array('code'=>-1,'msg'=>'内容错误')));
    }

    $title = $thread_info['subject'];
    $post_content = $post_info['message'];
    $time = date('Y-m-d H:i:s',$thread_info['create_date']);
    $author = user_read_cache($thread_info['uid'])['username'];
    $avatar = user_read_cache($thread_info['uid'])['avatar_url'];
    $link = url('thread-'. $tid);

    if( 
        empty($sitename) 
      ||empty($introduction)
      ||empty($link)
      ||empty($title)
      ||empty($post_content)
      ||empty($time)
      ||empty($author)
      ||empty($avatar)
    ){
        exit(json_encode(array('code'=>-1,'msg'=>'缺少参数')));
    }
    include _include(APP_PATH.'plugin/qg_thread_poster/service/api.php');
    
    $info = array(
        'sitename' => $sitename, //网站名称 
        'siteintr' => $introduction, //网站介绍
        'artclelink' => $link, //文章链接
        'artclename' => replace_title($title), //15个字
        'artclecont' => replace_content($post_content), //最多240个字
        'artcletime' => $time, //发布时间
        'artcleauth' => $author, //文章作者
        'artcleqqqq' => $avatar, //头像
    );
    
    $info['artclelink'] = get_http_type() . $_SERVER['HTTP_HOST'] .'/'. $link;
    $info['artcleqqqq'] = get_http_type() . $_SERVER['HTTP_HOST'] .'/'. $avatar;

    //计算阅读时间
    $read_time = round(mb_strlen($info['artclecont'], 'UTF-8')/500,1);
    //处理文章标题
    if(strlen($info['artclename'])>45){
        $info['artclename'] =  mb_substr($info['artclename'],0,15,'UTF-8').'...';
    }
    //处理文章内容
    if(strlen($info['artclecont'])>600){
        $info['artclecont'] =  mb_substr($info['artclecont'],0,200,'UTF-8').'...';
    }
    //生成二维码图片
    $qrCodeData = QRcode::pngData($info['artclelink'], 13);

    $config = array(
        'bg_url' => APP_PATH.'plugin/qg_thread_poster/service/img/background.png',
        'text' => array(
            array(
                'text' => date("d",strtotime($info['artcletime'])),
                'left' => 70, 
                'top' => 450, 
                'width' => 650,
                'fontSize' => 80, 
                'fontColor' => '255,255,255', 
                'angle' => 0,
            ),
            array(
                'text' => '-----------------',
                'left' => 70, 
                'top' => 470, 
                'width' => 650,
                'fontSize' => 15, 
                'fontColor' => '255,255,255', 
                'angle' => 0,
            ),
            array(
                'text' => date("Y",strtotime($info['artcletime'])).'/'.date("m",strtotime($info['artcletime'])),
                'left' => 80, 
                'top' => 490, 
                'width' => 650,
                'fontSize' => 20, 
                'fontColor' => '255,255,255', 
                'angle' => 0,
            ),
            array(
                'text' => $info['artclename'],
                'left' => 50, 
                'top' => 650, 
                'width' => 650,
                'fontSize' => 30, 
                'fontColor' => '0,0,0', 
                'angle' => 0,
            ),
            array(
                'text' => $info['artclecont'],
                'left' => 50, 
                'top' => 700, 
                'width' => 650,
                'fontSize' => 15, 
                'fontColor' => '85,85,85', 
                'angle' => 0,
            ),
            array(
                'text' => '文章编辑：'.$info['artcleauth'],
                'left' => 170,
                'top' => 940,
                'width' => 650,
                'fontSize' => 17,
                'fontColor' => '0,0,0',
                'angle' => 0,
            ),
            array(
                'text' => '预计阅读：'.$read_time.'分钟',
                'left' => 170, 
                'top' => 970,
                'width' => 650,
                'fontSize' => 17, 
                'fontColor' => '0,0,0',
                'angle' => 0,
            ),
            array(
                'text' => '-----------------------------------------------------------------------------------------------------------',
                'left' => 0,
                'top' => 1050,
                'width' => 750,
                'fontSize' => 15,
                'fontColor' => '128,128,128',
                'angle' => 0,
            ),
            array(
                'text' => $info['sitename'],
                'left' => 100,
                'top' => 1170,
                'width' => 325,
                'fontSize' => 30,
                'fontColor' => '0,0,0',
                'angle' => 0,
            ),
            array(
                'text' => $info['siteintr'],
                'left' => 100,
                'top' => 1210,
                'width' => 325,
                'fontSize' => 15,
                'fontColor' => '85,85,85',
                'angle' => 0,
            ),
            array(
                'text' => '扫一扫，看文章',
                'left' => 540,
                'top' => 1250,
                'width' => 130,
                'fontSize' => 10,
                'fontColor' => '85,85,85', 
                'angle' => 0,
            ),
        ),
        'image' => array(
            array(
                'url' => 0,
                'stream' => get_curl('https://www.bing.com'.json_decode(get_curl("https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1"),true)['images'][0]['url']),
                'left' => 0,
                'top' => 0,
                'right' => 0,
                'bottom' => 0,
                'width' => 750,
                'height' => 550,
                'radius' => 0,
                'opacity' => 100
            ),
            array(
                'url' => 0,
                'stream' => get_curl($info['artcleqqqq']),
                'left' => 50,
                'top' => 900,
                'right' => 0,
                'bottom' => 0,
                'width' => 100,
                'height' => 100,
                'radius' => 50,
                'opacity' => 100
            ),
            array(
                'url' => 0,
                'stream' => $qrCodeData,
                'left' => 520,
                'top' => 1100,
                'right' => 0,
                'bottom' => 0,
                'width' => 130,
                'height' => 130,
                'radius' => 0,
                'opacity' => 100
            ),
        )
    );

    //加载模板
    poster::setConfig($config);
    //设置保存路径
    $res = poster::make();
    // $percent = 1;  #原图压缩，不缩放，但体积大大降低  
    // $res = (new imgcompress($res,$percent,2))->showRaw(); 
    //是否要清理缓存资源
    poster::clear();
    if (!$res) {
        exit(json_encode(array('code'=>-1,'msg'=>'生成失败，请重试')));
    } else {
        exit(json_encode(array('code'=>1,'msg'=>'生成成功，消耗内存:'.changeFileSize(memory_get_usage()),'img'=>base64_encode($res))));
    }
}

?>