<?php
/**

 **/
 
include _include(APP_PATH.'plugin/qg_thread_poster/service/inc/phpQrcode.class.php');
include _include(APP_PATH.'plugin/qg_thread_poster/service/inc/poster.class.php');
include _include(APP_PATH.'plugin/qg_thread_poster/service/config.inc.php');

//获取当前网址协议
function get_http_type()
{
    $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
    return $http_type;
}

//辅助类函数，转换单位
function changeFileSize($size, $dec = 2)
{
    $a   = array('Byte', 'KB', 'MB', 'GB', 'TB', 'PB');
    $pos = 0;
    while ($size >= 1024) {
        $size /= 1024;
        $pos++;
    }
    return round($size, $dec) . ' ' . $a[$pos];
}
//文章标题可以有英文
function replace_title($str){
    preg_match_all('/[a-zA-Z0-9\x{4e00}-\x{9fff}]+/u', $str, $matches);
    return join('', $matches[0]);
}
function replace_content($str){
    preg_match_all('/[\x{4e00}-\x{9fff}]+/u', $str, $matches);
    return join('', $matches[0]);
}
