case 'part_log': include APP_PATH.'plugin/ac_fjpro/part_log.php'; break;
