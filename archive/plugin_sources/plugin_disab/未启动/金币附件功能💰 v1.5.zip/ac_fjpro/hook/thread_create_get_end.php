<?php exit;
// +----------------------------------------------------------------------
// +----------------------------------------------------------------------
// | 功能: 金币功能
// +----------------------------------------------------------------------
$input['attach_coin_status'] = form_radio_yes_no('attach_coin_status', 0);
$input['content_coin_status'] = form_radio_yes_no('content_coin_status', 0);
$content_coin = 0;
$attach_coin = 0;
?>