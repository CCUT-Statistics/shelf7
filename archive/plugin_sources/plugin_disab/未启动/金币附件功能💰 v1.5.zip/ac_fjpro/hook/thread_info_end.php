<?php exit;
	//付费查看
	$html_pay = '<p style="padding:3px 5px;margin:10px auto;border:1px dashed #ea413c;font-size:14px;font-weight:normal ">本帖有隐藏内容，需向作者<b style="color:red">支付'.$thread['content_golds'].'金币</b>才能浏览 <a href="'.url('thread-contentPay-'.$tid).'" target="_blank" style="font-weight:bold; float:right;color:#1b97f4" onClick="return confirm(\'确定付费查看内容吗？\')" ><img style="width:20px;height:20px; position:relative; top:-3px;" src="./plugin/ac_fjpro/images/coin.png">购买主题</a><Div style="clear:both"></Div></p>';
	$preg_pay = preg_match_all('/\[pay\](.*?)\[\/pay\]/i',$first['message_fmt'],$array);
	//查找付费记录
	$content_pay = db_find_one('ws_thread_pay', array('tid' => $tid, 'uid' => $uid, 'type' => 1));
	if($thread['content_golds']){
		if($preg_pay){
			for($i=0;$i<count($array[0]);$i++){
				$a = $array[0][$i];
				$b = $array[1][$i];
				if($content_pay||$thread['uid']==$uid){
					$first['message_fmt'] = str_replace($a,$b,$first['message_fmt']);
				}else{
					$first['message_fmt'] = str_replace($a,$html_pay,$first['message_fmt']);
				}
			}
		}
	}else{
		$first['message_fmt'] = str_replace(array('[pay]','[/pay]'),'',$first['message_fmt']);
	}
?>