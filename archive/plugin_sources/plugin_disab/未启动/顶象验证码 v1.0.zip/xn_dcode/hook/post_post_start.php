include_once APP_PATH.'plugin/xn_dcode/model/dcode.fuc.php';
dcodecheck('dcode_post_create_on');