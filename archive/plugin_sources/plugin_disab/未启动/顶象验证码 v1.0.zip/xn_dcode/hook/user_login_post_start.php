include_once APP_PATH.'plugin/xn_dcode/model/dcode.fuc.php';
dcodecheck('dcode_user_login_on');