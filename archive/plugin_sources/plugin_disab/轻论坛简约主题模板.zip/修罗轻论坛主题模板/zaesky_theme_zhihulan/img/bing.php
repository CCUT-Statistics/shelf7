<?php

if($_GET['idx']==null){
$str=file_get_contents('https://cn.bing.com/HPImageArchive.aspx?idx=0&n=1');

}

$str=file_get_contents('https://cn.bing.com/HPImageArchive.aspx?idx='.$_GET['idx'].'&n=1');
if(preg_match("/<url>(.+?)<\/url>/ies",$str,$matches)){
$imgurl='https://cn.bing.com'.$matches[1];
}
if($imgurl){
header('Content-Type: image/JPEG');
@ob_end_clean();
@readfile($imgurl);
@flush(); @ob_flush();
exit();
}else{
exit('error');
}
?>